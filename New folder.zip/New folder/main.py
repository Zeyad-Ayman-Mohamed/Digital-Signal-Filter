# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and setti

from math import pi
import cmath
import json
from flask import Flask,jsonify, make_response, render_template, request
from flask import Flask, render_template
from flask_sock import Sock
from scipy.signal import butter, freqz
import matplotlib.pyplot as plt
from math import pi
import numpy as np
from scipy import signal
import cmath
import json
import pandas as pd

app = Flask(__name__)
sock = Sock(app)
def PolesAndZerosAdujesment(poles,zeros):
    Poles=[]
    Zeros=[]
    for i in range(0,len(poles)):
        Poles.append(complex(poles[i][0],poles[i][1]))
    for i in range(0,len(zeros)):
        Zeros.append(complex(zeros[i][0],zeros[i][1]))
    return Poles,Zeros
datatosite={
            "w": [],
            "H_dB": [],
            "phi":[],
            "w_allpass":[],
            "H_dB_allpass":[],
            "phi_allpass":[],
            "FilterdSignal":[],
            "FilteredSignalAllPass":[],
            "Time":[]



        }
x = datatosite
loaded_data = pd.read_csv("ECG.csv")
time = loaded_data["time_sec"]
InputSignal = loaded_data["filtered_ECG_mV"]
FilteredSignal=[]
PointsNumber=4
@app.route('/')
def index():
    return render_template('T5WebPage.html')


@sock.route('/echo')
def echo(sock):
    while True:
        data = sock.receive()
        data = json.loads(data)

        zerosfromsite=data["value"]
        polesfromsite=data["value2"]
        print("zeros",zerosfromsite)
        print("poles",polesfromsite)
        f_s=360;
        poles, zeros=PolesAndZerosAdujesment(polesfromsite, zerosfromsite)
        system = signal.ZerosPolesGain(zeros, poles, 1)
        system = system.to_tf()
        a = system.den
        b = system.num
        w, H = freqz(b, a, 4096)  # Calculate the frequency response
        w *= f_s / (2 * pi)  # Convert from rad/sample to Hz
        H_dB = 20 * np.log10(abs(H))
        phi = np.angle(H)  # Argument of H
        phi = np.unwrap(phi)  # Remove discontinuities
        phi *= 180 / pi
        warp_factors=np.linspace(-0.99, 0.99, 5)
        for i, wf in enumerate(warp_factors):
            WofAllPass, HofAllPass = signal.freqz([-wf, 1.0], [1.0, -wf])
            HofAllPassdB=20 * np.log10(abs(HofAllPass))
            AnglesofAllPass = np.unwrap(np.angle(HofAllPass))

        dividenumber=len(InputSignal)/PointsNumber
        InputSignalDivided = np.array_split(InputSignal, dividenumber)
        TimeDivided= np.array_split(time, dividenumber)
        for i in range(0, len(InputSignalDivided))  :
            for j in range(0, PointsNumber):
                FilteredSignal = signal.lfilter(b, a, InputSignal[i][j])







        FilteredSignlAllPass=y = signal.lfilter([-wf, 1.0], [1.0, -wf], FilteredSignal)
        #we need to draw w with hdb, w with phi so we will put them in a dic send them
        #we need to draw w of all pass with hdb all pass and angle of all pass , put them in dic to send them
        #print("high")
        x["w"]=w
        x["H_dB"]=H_dB
        x["phi"]=phi
        x["w_allpass"] = WofAllPass
        x["H_dB_allpass"] = HofAllPassdB
        x["phi_allpass"] = AnglesofAllPass
        x["FilterdSignal"] =FilteredSignal
        x["FilteredSignalAllPass"] =FilteredSignlAllPass
        x["Time"] =TimeDivided

        print(x)
        try:
            datasenttosite = json.dumps(x)
            #print("data",x)

            sock.send(datasenttosite)
        except:
            print("error")

